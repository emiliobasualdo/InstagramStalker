<?php
namespace InstagramStalker;

include __DIR__ . '/src/Stalker.php';

$argv[0] = "pilobasualdo";
$argv[1] = "Novation14";
$argv[2] = "milipereda";
$argv[3] = "true";

$stalker = new Stalker($argv);

echo "Stalking from: {$argv[0]}.\n";
echo "User to stalk: {$argv[2]}\n";

$stalker->start();

